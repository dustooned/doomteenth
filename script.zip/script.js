// script.js

// 1. Update Body Background Gradient
function updateBodyBackground() {
  const scrollY = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = Math.min(scrollY / docHeight, 1);
  // Interpolate between dark black (rgb(0,0,0)) and dark orange (rgb(93, 140, 211))
  const r = Math.round(255 * progress);
  const g = Math.round(68 * progress);
  const b = Math.round(51 * progress);
  const color = `rgb(${r},${g},${b})`;
  // Apply as uniform background gradient
  document.body.style.background = `linear-gradient(135deg, ${color}, ${color})`;
}
window.addEventListener("scroll", updateBodyBackground);
window.addEventListener("load", updateBodyBackground);

// 2. Update Bottom Graphic Visibility
const bottomGraphic = document.getElementById("bottom-graphic");
function updateBottomGraphic() {
  const scrollY = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = Math.min(scrollY / docHeight, 1);
  // Show bottom graphic when progress exceeds 0.8
  if (progress > 0.8) {
    const localProgress = (progress - 0.8) / 0.2; // maps 0.8-1 to 0-1
    bottomGraphic.style.opacity = localProgress;
    // TranslateY from 100% (hidden) to 0 (visible)
    bottomGraphic.style.transform = `translateY(${(1 - localProgress) * 100}%)`;
  } else {
    bottomGraphic.style.opacity = 0;
    bottomGraphic.style.transform = "translateY(100%)";
  }
}
window.addEventListener("scroll", updateBottomGraphic);
window.addEventListener("load", updateBottomGraphic);

// 3. Update Horizontal Moving SVG Position
const movingSvg = document.getElementById("moving-svg");
function updateMovingSvgPosition() {
  const scrollY = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = Math.min(scrollY / docHeight, 1);
  // Map progress linearly to 0% to 100%
  const xPercent = progress * 100;
  movingSvg.style.left = xPercent + "%";
}
window.addEventListener("scroll", updateMovingSvgPosition);
window.addEventListener("load", updateMovingSvgPosition);

function updateMovingSvgColor() {
  const scrollY = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = Math.min(scrollY / docHeight, 1); // value between 0 and 1
  
  // Define starting and ending colors:
  const startColor = { r: 255, g: 255, b: 255};
  const endColor   = {  r: 255, g: 140, b: 0 };
  
  // Linearly interpolate each color channel:
  const r = Math.round(startColor.r * (1 - progress) + endColor.r * progress);
  const g = Math.round(startColor.g * (1 - progress) + endColor.g * progress);
  const b = Math.round(startColor.b * (1 - progress) + endColor.b * progress);
  
  const newColor = `rgb(${r}, ${g}, ${b})`;
  console.log("newColor =", newColor); // Debug output
  
  // Update the moving SVG's circle fill:
  const circle = document.querySelector("#moving-svg circle");
  if (circle) {
    circle.setAttribute("fill", newColor);
  } else {
    console.warn("No <circle> element found inside #moving-svg.");
  }
}

// 4. Starfield with Adjustable Glow
function getStarGlowAlpha() {
  const scrollY = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = Math.min(scrollY / docHeight, 1);
  // Glow alpha goes from 0.7 at top to 0.2 at bottom
  return Math.max(0.2, 0.7 - 0.5 * progress);
}

const canvas = document.createElement('canvas');
document.body.appendChild(canvas);
canvas.style.position = 'fixed';
canvas.style.top = 0;
canvas.style.left = 0;
canvas.style.width = '100%';
canvas.style.height = '100%';
canvas.style.zIndex = '-1';
canvas.style.pointerEvents = 'none';

const ctx = canvas.getContext('2d');
let width, height, particles;
function resize() {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight;
  particles = Array.from({ length: 80 }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    radius: Math.random() * 2 + 1,
    speedX: (Math.random() - 0.5) * 0.5,
    speedY: (Math.random() - 0.5) * 0.5
  }));
}
resize();
window.addEventListener('resize', resize);

function animate() {
  ctx.clearRect(0, 0, width, height);
  const alpha = getStarGlowAlpha();
  particles.forEach(p => {
    p.x += p.speedX;
    p.y += p.speedY;

    if (p.x < 0 || p.x > width) p.speedX *= -1;
    if (p.y < 0 || p.y > height) p.speedY *= -1;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,255,255,${alpha})`;
    ctx.fill();
  });
  requestAnimationFrame(animate);
}
animate();
